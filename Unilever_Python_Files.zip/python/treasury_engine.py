"""
treasury_engine.py — the Python re-implementation of the Step 3 cash logic.

One job: given inputs IMPORTED from the Excel workbook (assumptions + 2025 bases),
compute drivers, the 13-week cash path, funding and surplus metrics.
Contains no Unilever numbers; everything arrives through the `inputs` dict.
Transparent arithmetic only (numpy) — no black box.
"""
import datetime as dt
import numpy as np

WEEKS = np.arange(1, 14)


def drivers(a, h):
    """Annual forecast drivers for one scenario. a = scenario assumptions, h = 2025 bases (LIQUIDITY_DRIVERS col D)."""
    g = a["rev_growth"]
    d = {}
    d["rev_f"] = h["rev"] * (1 + g)
    d["coll_a"] = d["rev_f"] * (1 + a["coll_shock"])
    d["coll_d"] = d["coll_a"] / 365
    cash_opex = h["rev"] - h["ocf"]
    supp_2025 = cash_opex - a["payroll"] - h["other_out"]
    d["supp_f"] = supp_2025 * (1 + g)
    d["payroll_f"] = a["payroll"]
    d["other_out_f"] = h["other_out"]
    d["other_in_f"] = h["other_in"]
    d["cogs_d"] = h["cos"] * (1 + g) / 365
    d["capex_f"] = h["capex_i"] * d["rev_f"] * a["capex_mult"]
    d["tax_f"] = h["pbt_m"] * d["rev_f"] * h["etr"] * h["cashtax"] * a["tax_mult"]
    floating = h["fl"] * (1 - a["fixed_share"])
    d["int_f"] = -h["intpaid"] + floating * a["rate_bp"] / 10000
    d["fund_r"] = a["fund_rate"] + a["rate_bp"] / 10000
    d["mat_a"] = h["flc"]
    d["div_q"] = -h["div"] / 4 * (1 + a["div_growth"])
    d["bb_f"] = -h["bb"] * a["bb_mult"]
    d["wc_tot"] = d["coll_d"] * a["coll_delay"] + d["cogs_d"] * (a["inv_days"] + a["pay_days"])
    d["gross_out_w"] = (d["supp_f"] + d["payroll_f"] + d["other_out_f"] + d["tax_f"] + d["capex_f"] + d["int_f"]) / 52
    return d


def calendar(a):
    bs = a["bs_date"]
    bs = bs.date() if isinstance(bs, dt.datetime) else bs
    start = [bs + dt.timedelta(days=int(1 + a["days_wk"] * (w - 1))) for w in range(1, 14)]
    end = [s + dt.timedelta(days=int(a["days_wk"] - 1)) for s in start]
    month_end = np.array([1 if s.month != (e + dt.timedelta(days=1)).month else 0 for s, e in zip(start, end)])
    return start, end, month_end


def weekly(a, h, opening_cash, buffer):
    """Full 13-week engine for one scenario. Returns dict of numpy arrays (Excel line items)."""
    d = drivers(a, h)
    start, end, me = calendar(a)
    dpw = a["days_wk"]

    def prof(annual, key):
        return annual / 12 * me if a[key] == "Month-end" else np.full(13, annual / 52)

    def ramp(days, daily):
        return daily * (np.minimum(days, dpw * WEEKS) - np.minimum(days, dpw * (WEEKS - 1)))

    L = {}
    L["coll"] = prof(d["coll_a"], "coll_prof")
    L["delay"] = -ramp(a["coll_delay"], d["coll_d"])
    L["oin"] = prof(d["other_in_f"], "other_in_prof")
    L["mat"] = np.full(13, a["inv_mat"] / 13)
    L["tin"] = L["coll"] + L["delay"] + L["oin"] + L["mat"]
    L["supp"] = -prof(d["supp_f"], "supp_prof")
    L["invb"] = -ramp(a["inv_days"], d["cogs_d"])
    L["payb"] = -ramp(a["pay_days"], d["cogs_d"])
    L["payroll"] = -prof(d["payroll_f"], "payroll_prof")
    L["tax"] = -prof(d["tax_f"], "tax_prof")
    L["capex"] = -prof(d["capex_f"], "capex_prof")
    L["intr"] = -prof(d["int_f"], "int_prof")
    L["oout"] = -prof(d["other_out_f"], "other_out_prof")
    L["tout"] = sum(L[k] for k in ["supp", "invb", "payb", "payroll", "tax", "capex", "intr", "oout"])
    L["fx"] = a["fx_shock"] * ((1 - a["in_eur"]) * L["tin"] + (1 - a["out_eur"]) * L["tout"])
    L["opnet"] = L["tin"] + L["tout"] + L["fx"]
    L["repay"] = np.full(13, -d["mat_a"] / 52)
    L["refi"] = np.full(13, d["mat_a"] / 52 * a["refi"])
    div_date = a["div_date"].date() if isinstance(a["div_date"], dt.datetime) else a["div_date"]
    L["div"] = np.array([-d["div_q"] if s <= div_date <= e else 0.0 for s, e in zip(start, end)])
    L["bb"] = -prof(d["bb_f"], "bb_prof")
    L["ofin"] = np.full(13, a["other_fin"] / 13)
    L["sched"] = L["refi"] + L["repay"] + L["div"] + L["bb"] + L["ofin"]
    L["net"] = L["opnet"] + L["sched"]
    L["q"] = opening_cash + np.cumsum(L["net"])
    # sequential revolver (week by week, exactly as the Excel engine) — no circularity
    open_, pre, draw, rep, bal, close = (np.zeros(13) for _ in range(6))
    prev_close, prev_bal = opening_cash, 0.0
    for i in range(13):
        open_[i] = prev_close
        pre[i] = open_[i] + L["opnet"][i] + L["sched"][i]
        draw[i] = max(0.0, buffer - pre[i])
        rep[i] = -min(prev_bal, max(0.0, pre[i] - buffer))
        bal[i] = prev_bal + draw[i] + rep[i]
        close[i] = pre[i] + draw[i] + rep[i]
        prev_close, prev_bal = close[i], bal[i]
    L.update(open=open_, pre=pre, draw=draw, rep=rep, bal=bal, close=close,
             netfin=L["sched"] + draw + rep, netmov=L["opnet"] + L["sched"] + draw + rep, buf=np.full(13, buffer),
             week=WEEKS.astype(float), month_end=me.astype(float))
    return L, d


def methodology_buffer(a_base, h):
    d = drivers(a_base, h)
    return d["gross_out_w"] * a_base["stress_mult"] * a_base["cover_wks"] + a_base["restricted"]


def facilities(a):
    return a["fac_usd"] / a["eurusd"] + a["fac_eur"]


def metrics(q, buffer, fund_rate, a, facility):
    """Closed-form treasury metrics for a cumulative pre-funding cash path q and a buffer level."""
    acc = a["days_wk"] / a["day_count"]
    bal = np.maximum(0.0, buffer - q)                       # funding outstanding needed to hold the buffer
    surplus = np.maximum(0.0, q - buffer - a["headroom"])   # cash above buffer + headroom
    funding_cost = fund_rate * acc * bal.sum()
    income = a["yield"] * a["inv_share"] * acc * surplus.sum()
    peak = bal.max()
    return dict(min_cash=q.min(), week_of_min=int(np.argmin(q)) + 1, max_funding=peak, max_util=peak / facility,
                funding_cost=funding_cost, investment_income=income, net_cost=funding_cost - income,
                avg_surplus=surplus.mean(), weeks_below=int((q < buffer).sum()), weekly_bal=bal, weekly_surplus=surplus)


def cash_path(a, h, opening_cash, buffer):
    L, d = weekly(a, h, opening_cash, buffer)
    return L["q"], d