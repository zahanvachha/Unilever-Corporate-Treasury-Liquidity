"""run_all.py — run the pipeline 01 → 07 in order; stop at the first failing step."""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = ["01_import_excel.py", "02_validate_excel.py", "03_reproduce_excel.py", "04_buffer_analysis.py",
         "05_sensitivity.py", "06_robustness.py", "07_outputs.py"]
for s in STEPS:
    print(f"\n==================== {s}")
    r = subprocess.run([sys.executable, s], cwd=HERE)
    if r.returncode != 0:
        print(f"\nPIPELINE STOPPED at {s}"); sys.exit(r.returncode)
print("\nPIPELINE COMPLETE")