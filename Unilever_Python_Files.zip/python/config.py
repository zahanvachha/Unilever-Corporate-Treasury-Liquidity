"""
config.py — paths, tolerances, analysis grids and the EXCEL CELL MAP.

One job: tell every other script where things live in the frozen workbook.
Rows are located by their label text in column A (not by hard-coded row numbers),
so a moved row fails loudly instead of silently reading the wrong cell.
No Excel output values are typed here.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "data" / "Unilever_Treasury_STEP3_FINAL.xlsx"
OUTPUT = ROOT / "output"
CHARTS = ROOT / "charts"
IMPORT_PICKLE = OUTPUT / "imported_excel.pkl"
RESULTS_XLSX = OUTPUT / "Unilever_Treasury_PYTHON_RESULTS.xlsx"

SCENARIOS = ["Base", "Downside", "Severe"]
SCEN_COL = {"Base": "B", "Downside": "C", "Severe": "D"}          # ASSUMPTIONS columns
LD_SCEN_COL = {"Base": "E", "Downside": "F", "Severe": "G"}       # LIQUIDITY_DRIVERS forecast columns
WEEK_COLS = [chr(c) for c in range(ord("C"), ord("O") + 1)]       # 13W_FORECAST / SCENARIOS W1..W13

REQUIRED_SHEETS = ["ASSUMPTIONS", "LIQUIDITY_DRIVERS", "13W_FORECAST", "SCENARIOS", "LIQUIDITY_BUFFER",
                   "FUNDING", "SURPLUS_CASH", "FX_LIQUIDITY", "OPTIMISATION", "TREASURY_OUTPUT", "STEP3_CHECKS"]

# ---------------------------------------------------------------- CELL MAP (label in column A -> python key)
ASSUMPTION_LABELS = {
    "Opening balance-sheet date": "bs_date",
    "Days per forecast week": "days_wk",
    "Day-count basis for interest": "day_count",
    "Cash restricted by FX / legal controls (YE2025)": "restricted",
    "Undrawn committed revolving facilities — USD": "fac_usd",
    "Undrawn committed revolving facilities — EUR": "fac_eur",
    "EUR/USD rate for converting USD facilities": "eurusd",
    "Revenue growth vs 2025 continuing run-rate (annualised)": "rev_growth",
    "Customer collections shock (level)": "coll_shock",
    "Additional collection delay": "coll_delay",
    "Collections timing profile": "coll_prof",
    "Additional inventory days (inventory build)": "inv_days",
    "Reduction in payables support (earlier supplier payment)": "pay_days",
    "Supplier payment timing profile": "supp_prof",
    "Employee benefits expense — cash payroll proxy": "payroll",
    "Payroll timing profile": "payroll_prof",
    "Tax cash payments vs run-rate": "tax_mult",
    "Tax payment timing profile": "tax_prof",
    "Capex vs run-rate": "capex_mult",
    "Capex timing profile": "capex_prof",
    "Other operating outflows timing profile": "other_out_prof",
    "Other operating inflows timing profile": "other_in_prof",
    "Asset / investment maturities over 13 weeks (net inflow)": "inv_mat",
    "Interest-rate shock": "rate_bp",
    "Share of financial liabilities at fixed rate (2026)": "fixed_share",
    "Interest on existing debt timing profile": "int_prof",
    "Modelled funding rate on liquidity drawings (before shock)": "fund_rate",
    "Maximum facility utilisation before breach flag": "fac_limit",
    "Dividend growth vs 2025 quarterly average": "div_growth",
    "Next dividend payment date": "div_date",
    "Share buybacks vs 2025 run-rate": "bb_mult",
    "Buyback timing profile": "bb_prof",
    "Refinancing of scheduled debt maturities": "refi",
    "Other financing flows over 13 weeks": "other_fin",
    "Surplus-cash investment yield (annual)": "yield",
    "Share of surplus that is investable": "inv_share",
    "Operating headroom kept uninvested above the buffer": "headroom",
    "Non-EUR currencies vs EUR (uniform shock)": "fx_shock",
    "Operating inflows — EUR share": "in_eur",
    "Operating outflows — EUR share": "out_eur",
    "Coverage period": "cover_wks",
    "Stress uplift on weekly gross outflows": "stress_mult",
    "Buffer grid — first level": "buf_start",
    "Buffer grid — step": "buf_step",
    "Funding-rate grid — first level": "rate_start",
    "Funding-rate grid — step": "rate_step",
    "Collection-delay grid — first level": "delay_start",
    "Collection-delay grid — step": "delay_step",
    "Check tolerance": "tol",
}
# LIQUIDITY_DRIVERS column D (2025 historical bases, derived in Excel from Step 2)
LD_HIST_LABELS = {
    "Revenue (turnover)": "rev",
    "Operating cash flow (before tax)": "ocf",
    "of which pensions and provision payments": "other_out",
    "Dividends from JVs, associates and other investments": "other_in",
    "Cost of sales": "cos",
    "Capex ÷ revenue": "capex_i",
    "Effective tax rate": "etr",
    "PBT margin": "pbt_m",
    "Cash tax ÷ tax charge": "cashtax",
    "Interest paid": "intpaid",
    "Total financial liabilities (year-end)": "fl",
    "Current financial liabilities (year-end)": "flc",
    "Dividends paid": "div",
    "Share buybacks": "bb",
}
# LIQUIDITY_DRIVERS forecast columns E–G (Excel drivers Python must reproduce)
LD_DRIVER_LABELS = {
    "Forecast annual revenue": "rev_f",
    "Forecast annual customer collections (run-rate)": "coll_a",
    "Daily customer collections": "coll_d",
    "Forecast annual supplier payments": "supp_f",
    "Forecast annual payroll (employee benefits expense proxy)": "payroll_f",
    "Forecast daily cost of sales": "cogs_d",
    "Forecast annual capex (2025 intensity × forecast revenue)": "capex_f",
    "Forecast annual tax cash payments": "tax_f",
    "Forecast annual interest on existing debt": "int_f",
    "Funding rate on liquidity drawings (base + shock)": "fund_r",
    "Forecast quarterly dividend payment": "div_q",
    "Forecast annual share buybacks": "bb_f",
    "Incremental working-capital cash requirement": "wc_tot",
    "Weekly gross operating outflows (run-rate)": "gross_out_w",
}
# 13W_FORECAST weekly rows (selected scenario = Base in the frozen file)
FORECAST_LABELS = {
    "Week": "week", "Start date": "start", "End date": "end",
    "Month-end week (1 = contains a month end)": "month_end",
    "Opening cash": "open",
    "Customer collections (run-rate)": "coll", "Collection delay — cash tied up": "delay",
    "Other operating inflows (JV / associate dividends)": "oin", "Asset / investment maturities": "mat",
    "Total inflows": "tin",
    "Supplier and other operating payments (run-rate)": "supp", "WC stress — inventory build": "invb",
    "WC stress — reduced payables support": "payb", "Payroll (employee benefits expense — cash payroll proxy)": "payroll",
    "Tax": "tax", "Capex": "capex", "Interest on existing debt (incl. floating-rate shock)": "intr",
    "Other operating outflows (pensions, provisions)": "oout", "Total operating outflows": "tout",
    "FX impact on non-EUR operating flows": "fx", "Operating net cash flow": "opnet",
    "Debt drawdowns — scheduled refinancing": "refi", "Debt repayments — scheduled maturities": "repay",
    "Dividends": "div", "Share buybacks": "bb", "Other financing": "ofin", "Net scheduled financing": "sched",
    "Closing cash before liquidity funding": "pre", "Minimum liquidity buffer": "buf",
    "Debt drawdowns — liquidity facility": "draw", "Debt repayments — liquidity facility": "rep",
    "Net financing cash flow": "netfin", "Net cash movement": "netmov", "Closing cash": "close",
    "Liquidity facility drawn (outstanding)": "bal", "Cumulative cash before any liquidity funding": "q",
}
FORECAST_SINGLE = {  # column C single values
    "Selected scenario": "selected",
    "Cash & cash equivalents — balance sheet (opening cash)": "opening_cash",
    "Other current financial assets": "ocfa",
    "Restricted cash (FX / legal controls)": "restricted_cash",
    "Undrawn committed facilities (EUR equivalent)": "facilities",
}
SCENARIO_ROW_LABELS = {
    "Base — weekly net cash flow (operating + scheduled financing)": ("Base", "net"),
    "Base — cumulative cash before liquidity funding": ("Base", "q"),
    "Downside — weekly net cash flow (operating + scheduled financing)": ("Downside", "net"),
    "Downside — cumulative cash before liquidity funding": ("Downside", "q"),
    "Severe — weekly net cash flow (operating + scheduled financing)": ("Severe", "net"),
    "Severe — cumulative cash before liquidity funding": ("Severe", "q"),
    "Base — delay that brings cash to the buffer": ("Base", "rs"),
    "Downside — delay that brings cash to the buffer": ("Downside", "rs"),
    "Severe — delay that brings cash to the buffer": ("Severe", "rs"),
}
OUTPUT_KPI_LABELS = {
    "Opening cash (balance sheet, 31 Dec 2025)": "opening_cash",
    "Minimum liquidity requirement (modelled buffer)": "buffer",
    "Minimum projected cash before liquidity funding": "min_cash",
    "Maximum funding requirement": "max_funding",
    "Total 13-week funding cost": "funding_cost",
    "Average weekly surplus cash": "avg_surplus",
    "13-week investment income": "investment_income",
    "Net treasury cost (funding cost − investment income)": "net_cost",
    "Maximum facility utilisation": "max_util",
    "Weeks below buffer before funding": "weeks_below",
    "Model-selected buffer": "model_selected_buffer",
}
COMPARISON_LABELS = {  # TREASURY_OUTPUT scenario comparison table (B/C/D)
    "Minimum projected cash (before liquidity funding)": "min_cash",
    "Modelled liquidity buffer": "buffer",
    "Maximum funding requirement": "max_funding",
    "Peak facility utilisation": "max_util",
    "Funding cost (13 weeks)": "funding_cost",
    "Investment income (13 weeks)": "investment_income",
    "Net treasury cost (funding cost − investment income)": "net_cost",
    "Weeks below buffer before funding": "weeks_below",
    "Reverse stress: extra collection delay before funding is needed (days)": "reverse_stress",
}

# ---------------------------------------------------------------- Python analysis settings (not Excel outputs)
BUFFER_GRID = dict(start=1000, stop=5000, step=100)       # €m; must bracket the Excel model-selected buffer
DELAY_GRID = list(range(0, 21, 2))                         # days; brackets Excel's 0 / 7 / 15-day scenarios
RATE_OFFSETS = [-0.010, -0.005, 0.0, 0.005, 0.010]         # around the Excel funding-rate assumption
YIELD_OFFSETS = [-0.010, -0.005, 0.0, 0.005, 0.010]        # around the Excel investment-yield assumption
ROBUST_SCALE = dict(lower=0.5, higher=1.5)                 # one-at-a-time scaling of stress deltas
RATE_SHIFT = 0.010                                         # one-at-a-time rate / yield shift
COLOURS = {"Base": "#2a78d6", "Downside": "#eb6834", "Severe": "#1baf7a"}