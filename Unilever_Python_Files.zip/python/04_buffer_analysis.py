"""
04_buffer_analysis.py — liquidity-buffer grid across Base / Downside / Severe.

One job: evaluate candidate buffers against the SAME liquidity constraint the Excel model uses,
select a buffer per scenario and a single robust buffer across all three.
Runs only after 03_reproduce_excel.py has passed.

Constraint (identical concept to Excel OPTIMISATION):
  (i)  stress coverage: usable buffer (buffer − restricted cash) ≥ the scenario's peak cash drain vs Base
  (ii) facility capacity: funding needed to hold the buffer ≤ committed facilities × utilisation limit
Objective: net treasury cost = funding cost − investment income (no extra penalties).
Output: output/buffer_analysis.pkl
"""
import pickle
import sys
import numpy as np
import pandas as pd
import config as C
import treasury_engine as E


def evaluate(A, H, opening, buffer_grid, paths, facility):
    rows = []
    q_base = paths["Base"]
    for s in C.SCENARIOS:
        a = A[s]; q = paths[s]
        fr = E.drivers(a, H)["fund_r"]
        drain = float(np.max(q_base - q)) if s != "Base" else 0.0
        for B in buffer_grid:
            m = E.metrics(q, B, fr, a, facility)
            gap = max(0.0, drain - (B - a["restricted"]))
            breach = m["max_funding"] > facility * a["fac_limit"]
            rows.append(dict(Scenario=s, Buffer=B, MinCash=m["min_cash"], PlannedFunding=m["max_funding"],
                             FacilityUtilisation=m["max_util"], FundingCost=m["funding_cost"], AvgSurplus=m["avg_surplus"],
                             InvestmentIncome=m["investment_income"], NetTreasuryCost=m["net_cost"], WeeksBelowBuffer=m["weeks_below"],
                             StressDrain=drain, UnabsorbedStress=gap, FacilityBreach=breach,
                             Feasible=(gap == 0) and not breach))
    df = pd.DataFrame(rows)
    df["Status"] = np.where(df.Feasible, "FEASIBLE", "INFEASIBLE")
    return df


def select(df):
    per = {}
    for s in C.SCENARIOS:
        f = df[(df.Scenario == s) & df.Feasible].sort_values(["NetTreasuryCost", "Buffer"])
        per[s] = f.iloc[0] if len(f) else None
    wide = df.pivot(index="Buffer", columns="Scenario")
    rob = pd.DataFrame({
        "WorstPlannedFunding": wide["PlannedFunding"].max(axis=1),
        "WorstNetTreasuryCost": wide["NetTreasuryCost"].max(axis=1),
        "WorstUnabsorbedStress": wide["UnabsorbedStress"].max(axis=1),
        "WorstUtilisation": wide["FacilityUtilisation"].max(axis=1),
        "FeasibleAllScenarios": wide["Feasible"].all(axis=1),
    })
    f = rob[rob.FeasibleAllScenarios].sort_values(["WorstNetTreasuryCost"])
    robust = f.index[0] if len(f) else None
    return per, rob, robust


if __name__ == "__main__":
    d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
    rep, ctx = pickle.load(open(C.OUTPUT / "reproduction.pkl", "rb"))
    if not (rep.Status == "PASS").all():
        print("Reproduction has not passed — analysis stopped."); sys.exit(1)
    A, H = d["assumptions"], d["hist2025"]
    g = C.BUFFER_GRID
    grid = np.arange(g["start"], g["stop"] + g["step"], g["step"], dtype=float)
    excel_sel = d["opt_selected"]
    assert grid.min() <= ctx["buffer"] <= grid.max() and grid.min() <= excel_sel <= grid.max(), "grid must bracket Excel buffers"
    df = evaluate(A, H, d["opening"]["opening_cash"], grid, ctx["paths"], ctx["facility"])
    per, rob, robust = select(df)
    # cross-check: on the Excel grid (1,000 to 4,500 step 500) Python must select the Excel model-selected buffer
    a0 = A["Base"]
    xgrid = a0["buf_start"] + a0["buf_step"] * np.arange(8)
    _, _, robust_x = select(evaluate(A, H, d["opening"]["opening_cash"], xgrid, ctx["paths"], ctx["facility"]))
    xcheck = dict(excel=excel_sel, python=robust_x, status="PASS" if robust_x == excel_sel else "ERROR")
    pickle.dump(dict(grid=df, per=per, robust_table=rob, robust=robust, excel_grid_check=xcheck), open(C.OUTPUT / "buffer_analysis.pkl", "wb"))
    print(f"Buffer grid: {grid.min():,.0f}–{grid.max():,.0f} step {g['step']} × {len(C.SCENARIOS)} scenarios = {len(df)} cases")
    for s in C.SCENARIOS:
        r = per[s]
        print(f"  {s:9s} model-selected buffer €{r.Buffer:,.0f}m | stress drain €{r.StressDrain:,.0f}m | net treasury cost €{r.NetTreasuryCost:,.1f}m")
    rr = rob.loc[robust]
    print(f"  ROBUST    model-selected robust liquidity buffer under stated assumptions: €{robust:,.0f}m "
          f"(worst-case planned funding €{rr.WorstPlannedFunding:,.0f}m, worst-case net cost €{rr.WorstNetTreasuryCost:,.1f}m)")
    print(f"  Excel-grid cross-check: Python {robust_x:,.0f} vs Excel {excel_sel:,.0f} -> {xcheck['status']}")