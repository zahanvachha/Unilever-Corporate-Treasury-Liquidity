"""
03_reproduce_excel.py — prove Python reproduces the Excel model before any analysis.

One job: recompute the Excel Step 3 results independently (treasury_engine.py) from the
imported assumptions and 2025 bases, compare every item with the Excel value, and stop
the pipeline if anything differs by more than the Excel check tolerance.
Output: output/reproduction.pkl (item-level audit trail)
"""
import datetime as dt
import pickle
import sys
import numpy as np
import pandas as pd
from scipy.optimize import brentq
import config as C
import treasury_engine as E


def as_date(x):
    return x.date() if isinstance(x, dt.datetime) else x


def reproduce(d):
    A, H = d["assumptions"], d["hist2025"]
    tol = A["Base"]["tol"]
    opening = d["opening"]["opening_cash"]
    rows = []

    def add(scen, group, item, week, excel, py):
        if isinstance(excel, (dt.date, dt.datetime)):
            ok = as_date(excel) == as_date(py); diff = 0.0 if ok else np.nan
        else:
            diff = float(py) - float(excel); ok = abs(diff) <= tol
        rows.append(dict(Scenario=scen, Group=group, Item=item, Week=week, Excel=excel, Python=py, Difference=diff,
                         Status="PASS" if ok else "ERROR"))

    # 1. calendar
    start, end, me = E.calendar(A["Base"])
    f = d["forecast"]
    for w in range(13):
        add("All", "Calendar", "Start date", w + 1, f["start"].iloc[w], start[w])
        add("All", "Calendar", "End date", w + 1, f["end"].iloc[w], end[w])
        add("All", "Calendar", "Month-end flag", w + 1, f["month_end"].iloc[w], me[w])
    # 2. opening position, buffer, facilities
    buffer = E.methodology_buffer(A["Base"], H)
    fac = E.facilities(A["Base"])
    add("All", "Liquidity position", "Modelled minimum liquidity buffer", None, d["buffer"]["modelled_buffer"], buffer)
    add("All", "Liquidity position", "Undrawn committed facilities (EUR)", None, d["opening"]["facilities"], fac)
    add("All", "Liquidity position", "Opening cash (W1 opening = balance-sheet cash)", None, f["open"].iloc[0], opening)
    # 3. drivers, every scenario
    ex = d["excel_drivers"]
    paths = {}
    for s in C.SCENARIOS:
        drv = E.drivers(A[s], H)
        for k in ex.index:
            add(s, "Drivers (LIQUIDITY_DRIVERS)", k, None, ex.loc[k, s], drv[k])
        L, _ = E.weekly(A[s], H, opening, buffer)
        paths[s] = L
        # 4. weekly net cash and cumulative cash before funding — every scenario (SCENARIOS sheet)
        for w in range(13):
            add(s, "Weekly net cash movement (before liquidity funding)", "Net cash movement", w + 1, d["scenarios"][(s, "net")][w], L["net"][w])
            add(s, "Closing cash (before liquidity funding)", "Closing cash before liquidity funding", w + 1, d["scenarios"][(s, "q")][w], L["q"][w])
    # 5. every Base line item (13W_FORECAST holds the selected scenario = Base)
    sel = d["opening"]["selected"]
    L = paths[sel]
    for k in [c for c in f.columns if c not in ("week", "start", "end", "month_end")]:
        for w in range(13):
            add(sel, "13W_FORECAST line items", k, w + 1, f[k].iloc[w], L[k][w])
    # 6. headline outputs, every scenario (TREASURY_OUTPUT comparison table)
    cmp_ = d["comparison"]
    M = {}
    for s in C.SCENARIOS:
        m = E.metrics(paths[s]["q"], buffer, E.drivers(A[s], H)["fund_r"], A[s], fac)
        M[s] = m
        for k in ["min_cash", "max_funding", "max_util", "funding_cost", "investment_income", "net_cost", "weeks_below"]:
            add(s, "Headline outputs (comparison table)", k, None, cmp_.loc[k, s], m[k])
        add(s, "Headline outputs (comparison table)", "buffer", None, cmp_.loc["buffer", s], buffer)
    # 7. selected-scenario KPIs, FUNDING and SURPLUS_CASH weekly rows
    o, m = d["outputs"], M[sel]
    for k in ["min_cash", "max_funding", "funding_cost", "investment_income", "net_cost", "max_util", "weeks_below", "avg_surplus"]:
        add(sel, "KPI block (TREASURY_OUTPUT)", k, None, o[k], m[k])
    acc = A[sel]["days_wk"] / A[sel]["day_count"]
    for w in range(13):
        add(sel, "FUNDING weekly", "Funding outstanding", w + 1, d["funding"]["weekly_outstanding"][w], L["bal"][w])
        add(sel, "FUNDING weekly", "Funding cost", w + 1, d["funding"]["weekly_cost"][w], L["bal"][w] * E.drivers(A[sel], H)["fund_r"] * acc)
        add(sel, "SURPLUS_CASH weekly", "Surplus cash", w + 1, d["surplus_cash"]["weekly_surplus"][w], m["weekly_surplus"][w])
        add(sel, "SURPLUS_CASH weekly", "Investment income", w + 1, d["surplus_cash"]["weekly_income"][w],
            m["weekly_surplus"][w] * A[sel]["yield"] * A[sel]["inv_share"] * acc)
    add(sel, "FUNDING totals", "Total funding cost", None, d["funding"]["total_cost"], m["funding_cost"])
    add(sel, "SURPLUS_CASH totals", "Total investment income", None, d["surplus_cash"]["total_income"], m["investment_income"])
    add(sel, "Revolver closed form", "Σ|sequential − MAX(0, buffer − cumulative)|", None, 0.0, float(np.abs(L["bal"] - m["weekly_bal"]).sum()))
    # 8. OPTIMISATION table (selected scenario) and model-selected buffer
    drain = float(np.max(paths["Base"]["q"] - paths["Severe"]["q"]))
    add("All", "OPTIMISATION", "Severe-stress peak drain vs Base", None, d["opt_drain"], drain)
    opt = d["optimisation"]
    feas = []
    for _, r in opt.iterrows():
        B = r["Buffer €m"]
        mm = E.metrics(L["q"], B, E.drivers(A[sel], H)["fund_r"], A[sel], fac)
        gap = max(0.0, drain - (B - A[sel]["restricted"]))
        py = {"Weeks below buffer": mm["weeks_below"], "Peak funding requirement": mm["max_funding"], "13-wk funding cost": mm["funding_cost"],
              "Avg surplus cash": mm["avg_surplus"], "13-wk investment income": mm["investment_income"], "Net treasury cost": mm["net_cost"],
              "Min liquidity headroom": mm["min_cash"] - B + fac, "Stress coverage gap": gap}
        for col, v in py.items():
            add(sel, "OPTIMISATION buffer table", f"{col} @ {B:,.0f}", None, r[col], v)
        ok = gap == 0 and mm["max_funding"] <= fac * A[sel]["fac_limit"]
        add(sel, "OPTIMISATION buffer table", f"Feasible @ {B:,.0f}", None, r["Feasible"], int(ok))
        if ok and abs(B - buffer) > 1e-9:
            feas.append(B)
    add(sel, "OPTIMISATION", "Model-selected buffer", None, d["opt_selected"], min(feas))
    # 9. sensitivity grids
    fr = E.drivers(A[sel], H)["fund_r"]
    for B, vals in d["sens1"].items():
        for rate, xv in zip(d["sens1_rates"], vals[:6]):
            mm = E.metrics(L["q"], B, rate, A[sel], fac)
            add(sel, "OPTIMISATION sensitivity 1", f"net cost @ buffer {B:,.0f}, rate {rate:.1%}", None, xv, mm["net_cost"])
    dly = A[sel]["coll_delay"]
    for delay, vals in d["sens2"].items():
        a2 = dict(A[sel]); a2["coll_delay"] = delay
        q2, _ = E.cash_path(a2, H, opening, buffer)
        add(sel, "OPTIMISATION sensitivity 2", f"peak funding @ delay {delay:.0f}", None, vals[6], max(0.0, buffer - q2.min()))
        for rate, xv in zip(d["sens2_rates"], vals[:6]):
            mm = E.metrics(q2, buffer, rate, A[sel], fac)
            add(sel, "OPTIMISATION sensitivity 2", f"funding cost @ delay {delay:.0f}, rate {rate:.1%}", None, xv, mm["funding_cost"])
    # 10. reverse stress (scipy root-finding reproduces the Excel closed form)
    for s in C.SCENARIOS:
        excel_rs = cmp_.loc["reverse_stress", s]
        d0 = A[s]["coll_delay"]
        def gap_fn(x, s=s):
            a2 = dict(A[s]); a2["coll_delay"] = x
            return E.cash_path(a2, H, opening, buffer)[0].min() - buffer
        if gap_fn(d0) < 0:
            add(s, "Reverse stress", "status", None, 1.0 if excel_rs == "Already needed" else 0.0, 1.0)
        else:
            root = brentq(gap_fn, d0, d0 + 13 * A[s]["days_wk"])
            add(s, "Reverse stress", "extra collection delay before funding (days)", None, excel_rs, root - d0)
    # 11. FX
    add(sel, "FX_LIQUIDITY", "Total FX impact = Σ weekly FX line", None, d["fx"]["total_impact"], float(L["fx"].sum()))
    rep = pd.DataFrame(rows)
    return rep, dict(buffer=buffer, facility=fac, drain=drain, paths={s: paths[s]["q"] for s in C.SCENARIOS}, metrics=M)


if __name__ == "__main__":
    d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
    rep, ctx = reproduce(d)
    pickle.dump((rep, ctx), open(C.OUTPUT / "reproduction.pkl", "wb"))
    print("EXCEL REPRODUCTION TEST\n")
    wk = rep[rep["Group"] == "Closing cash (before liquidity funding)"]
    for s in C.SCENARIOS:
        print(f"{s}:")
        print("  " + "  ".join(f"W{int(r.Week)} {r.Status}" for r in wk[wk.Scenario == s].itertuples()))
    print()
    for g, sub in rep.groupby("Group", sort=False):
        print(f"  {g:55s} {len(sub):4d} items  {'PASS' if (sub.Status == 'PASS').all() else 'ERROR'}  max|diff| = {np.nanmax(np.abs(sub.Difference.astype(float))):.2e}")
    ok = (rep.Status == "PASS").all()
    print(f"\n{len(rep)} items compared. Overall: {'PASS' if ok else 'ERROR'}")
    if not ok:
        print(rep[rep.Status != "PASS"].to_string()); sys.exit(1)