"""
05_sensitivity.py — one-way and two-way sensitivities around the Excel assumptions.

One job: vary one input at a time (collection delay, funding rate, investment yield) and one
two-way grid (collection delay × funding rate), recomputing the reproduced engine each time.
All metrics are measured at the Excel methodology buffer so they are comparable with the workbook.
Output: output/sensitivity.pkl
"""
import pickle
import numpy as np
import pandas as pd
import config as C
import treasury_engine as E


def run(d, ctx):
    A, H, opening = d["assumptions"], d["hist2025"], d["opening"]["opening_cash"]
    B, fac = ctx["buffer"], ctx["facility"]
    out = {}
    # collection delay (replaces each scenario's own delay; other stresses unchanged)
    rows = []
    for s in C.SCENARIOS:
        for delay in C.DELAY_GRID:
            a = dict(A[s]); a["coll_delay"] = delay
            q, dr = E.cash_path(a, H, opening, B)
            m = E.metrics(q, B, dr["fund_r"], a, fac)
            rows.append(dict(Scenario=s, CollectionDelayDays=delay, MinCash=m["min_cash"], MaxFunding=m["max_funding"],
                             FundingCost=m["funding_cost"], InvestmentIncome=m["investment_income"], NetTreasuryCost=m["net_cost"]))
    out["delay"] = pd.DataFrame(rows)
    # funding rate (base rate ± offsets; scenario rate shocks still added on top)
    rows = []
    for s in C.SCENARIOS:
        for off in C.RATE_OFFSETS:
            a = dict(A[s]); a["fund_rate"] = A[s]["fund_rate"] + off
            q, dr = E.cash_path(a, H, opening, B)
            m = E.metrics(q, B, dr["fund_r"], a, fac)
            rows.append(dict(Scenario=s, FundingRateBase=a["fund_rate"], FundingRateApplied=dr["fund_r"], FundingCost=m["funding_cost"],
                             InvestmentIncome=m["investment_income"], NetTreasuryCost=m["net_cost"]))
    out["rate"] = pd.DataFrame(rows)
    # investment yield
    rows = []
    for s in C.SCENARIOS:
        for off in C.YIELD_OFFSETS:
            a = dict(A[s]); a["yield"] = A[s]["yield"] + off
            q, dr = E.cash_path(a, H, opening, B)
            m = E.metrics(q, B, dr["fund_r"], a, fac)
            rows.append(dict(Scenario=s, InvestmentYield=a["yield"], InvestmentIncome=m["investment_income"],
                             FundingCost=m["funding_cost"], NetTreasuryCost=m["net_cost"]))
    out["yield"] = pd.DataFrame(rows)
    # two-way: collection delay × funding rate -> net treasury cost
    rows = []
    for s in C.SCENARIOS:
        for delay in C.DELAY_GRID:
            for off in C.RATE_OFFSETS:
                a = dict(A[s]); a["coll_delay"] = delay; a["fund_rate"] = A[s]["fund_rate"] + off
                q, dr = E.cash_path(a, H, opening, B)
                m = E.metrics(q, B, dr["fund_r"], a, fac)
                rows.append(dict(Scenario=s, CollectionDelayDays=delay, FundingRateBase=a["fund_rate"], NetTreasuryCost=m["net_cost"]))
    out["two_way"] = pd.DataFrame(rows)
    out["buffer_used"] = B
    return out


if __name__ == "__main__":
    d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
    rep, ctx = pickle.load(open(C.OUTPUT / "reproduction.pkl", "rb"))
    out = run(d, ctx)
    pickle.dump(out, open(C.OUTPUT / "sensitivity.pkl", "wb"))
    dl = out["delay"].pivot(index="CollectionDelayDays", columns="Scenario", values="MaxFunding")[C.SCENARIOS]
    print(f"Maximum funding requirement (€m) at the methodology buffer €{out['buffer_used']:,.0f}m, by collection delay:")
    print(dl.round(0).to_string())
    print("\nNet treasury cost (€m) by base funding rate:")
    print(out["rate"].pivot(index="FundingRateBase", columns="Scenario", values="NetTreasuryCost")[C.SCENARIOS].round(1).to_string())