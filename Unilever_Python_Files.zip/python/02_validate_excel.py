"""
02_validate_excel.py — input validation gate.

One job: confirm the imported Excel model is complete and internally passing BEFORE
any analysis. If any test fails, prints 'PYTHON INPUT VALIDATION: FAILED' and exits 1,
which stops the pipeline.
Output: output/validation_input.pkl
"""
import math
import pickle
import sys
import config as C


def is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def validate(d):
    f = d.get("forecast")
    tests = []
    def t(name, ok, detail=""):
        tests.append((name, "PASS" if ok else "FAIL", detail))
    t("Excel workbook loaded", "sheets_present" in d, d.get("workbook", ""))
    t("Required sheets present", not d["missing_sheets"], f"missing: {d['missing_sheets']}" if d["missing_sheets"] else "all 11")
    if d["missing_sheets"]:
        return tests
    t("Check 1 — 13 forecast weeks exist", len(f) == 13 and f["week"].notna().all(), f"{len(f)} weeks")
    t("Check 2 — weeks are sequential", list(f["week"]) == list(range(1, 14)), str(list(f["week"])))
    t("Check 3 — Base / Downside / Severe exist", d["assumption_header"] == C.SCENARIOS
      and all(("%s" % s, "q") in [(k[0], k[1]) for k in d["scenarios"]] for s in C.SCENARIOS), str(d["assumption_header"]))
    t("Check 4 — opening cash exists", is_num(d["opening"]["opening_cash"]), str(d["opening"]["opening_cash"]))
    t("Check 5 — minimum liquidity exists", is_num(d["buffer"]["modelled_buffer"]), str(d["buffer"]["modelled_buffer"]))
    t("Check 6 — closing cash exists for all 13 weeks", all(is_num(x) for x in f["close"]) and all(
        all(is_num(x) for x in d["scenarios"][(s, "q")][:13]) for s in C.SCENARIOS), "engine + 3 scenario paths")
    t("Check 7 — funding requirement exists", all(is_num(x) for x in d["funding"]["weekly_outstanding"]) and all(
        is_num(d["comparison"].loc["max_funding", s]) for s in C.SCENARIOS), "")
    t("Check 8 — funding cost exists", is_num(d["funding"]["total_cost"]) and all(is_num(d["comparison"].loc["funding_cost", s]) for s in C.SCENARIOS), "")
    t("Check 9 — investment income exists", is_num(d["surplus_cash"]["total_income"]) and all(is_num(d["comparison"].loc["investment_income", s]) for s in C.SCENARIOS), "")
    core = d["excel_checks"]
    t("Check 10 — Excel core Step 3 checks all PASS", len(core) == 12 and all(v == "PASS" for v in core.values()),
      f"{sum(v == 'PASS' for v in core.values())}/12 PASS")
    return tests


if __name__ == "__main__":
    d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
    tests = validate(d)
    for name, st, det in tests:
        print(f"  {st:4s}  {name}  {det}")
    ok = all(st == "PASS" for _, st, _ in tests)
    pickle.dump(tests, open(C.OUTPUT / "validation_input.pkl", "wb"))
    if not ok:
        failed = [n for n, s, _ in tests if s != "PASS"]
        print("PYTHON INPUT VALIDATION: FAILED —", "; ".join(failed)); sys.exit(1)
    print("PYTHON INPUT VALIDATION: PASS")