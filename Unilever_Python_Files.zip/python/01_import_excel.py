"""
01_import_excel.py — read the frozen Step 3 workbook into named Python objects.

One job: import. Reads cached formula results (data_only=True) from the frozen
workbook, locating every row by its label (see config.py). Writes nothing to Excel.
Output: output/imported_excel.pkl
"""
import pickle
import sys
import openpyxl
import pandas as pd
import config as C


def label_rows(ws, col="A", start=1, stop=None):
    """Map label text in column A -> row number (first occurrence within [start, stop])."""
    out = {}
    for r in range(start, (stop or ws.max_row) + 1):
        v = ws[f"{col}{r}"].value
        if isinstance(v, str) and v.strip() and v not in out:
            out[v.strip()] = r
    return out


def find(rows, label, sheet):
    if label not in rows:
        raise KeyError(f"Label not found on {sheet}: '{label}'")
    return rows[label]


def import_excel(path=C.WORKBOOK):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    missing = [s for s in C.REQUIRED_SHEETS if s not in wb.sheetnames]
    data = {"workbook": str(path), "sheets_present": wb.sheetnames, "missing_sheets": missing}
    if missing:
        return data

    # ---- ASSUMPTIONS: one column per scenario
    ws = wb["ASSUMPTIONS"]; rows = label_rows(ws)
    assumptions = {s: {} for s in C.SCENARIOS}
    for label, key in C.ASSUMPTION_LABELS.items():
        r = find(rows, label, "ASSUMPTIONS")
        for s in C.SCENARIOS:
            assumptions[s][key] = ws[f"{C.SCEN_COL[s]}{r}"].value
    data["assumptions"] = assumptions
    data["assumption_header"] = [ws[f"{c}4"].value for c in "BCD"]

    # ---- LIQUIDITY_DRIVERS: 2025 bases (col D) and Excel drivers (E–G)
    ws = wb["LIQUIDITY_DRIVERS"]; rows = label_rows(ws)
    data["hist2025"] = {k: ws[f"D{find(rows, lab, 'LIQUIDITY_DRIVERS')}"].value for lab, k in C.LD_HIST_LABELS.items()}
    drivers = {s: {} for s in C.SCENARIOS}
    for lab, k in C.LD_DRIVER_LABELS.items():
        r = find(rows, lab, "LIQUIDITY_DRIVERS")
        for s in C.SCENARIOS:
            drivers[s][k] = ws[f"{C.LD_SCEN_COL[s]}{r}"].value
    data["excel_drivers"] = pd.DataFrame(drivers)

    # ---- 13W_FORECAST: weekly engine (selected scenario) + opening position
    ws = wb["13W_FORECAST"]; rows = label_rows(ws)
    forecast = {}
    for lab, k in C.FORECAST_LABELS.items():
        r = find(rows, lab, "13W_FORECAST")
        forecast[k] = [ws[f"{c}{r}"].value for c in C.WEEK_COLS]
    data["forecast"] = pd.DataFrame(forecast, index=pd.Index(range(1, 14), name="week_no"))
    data["opening"] = {k: ws[f"C{find(rows, lab, '13W_FORECAST')}"].value for lab, k in C.FORECAST_SINGLE.items()}

    # ---- SCENARIOS: weekly net and cumulative cash per scenario, reverse-stress helper
    ws = wb["SCENARIOS"]; rows = label_rows(ws)
    sc = {}
    for lab, (s, k) in C.SCENARIO_ROW_LABELS.items():
        r = find(rows, lab, "SCENARIOS")
        sc[(s, k)] = [ws[f"{c}{r}"].value for c in C.WEEK_COLS] + [ws[f"B{r}"].value]
    data["scenarios"] = sc

    # ---- LIQUIDITY_BUFFER / FUNDING / SURPLUS_CASH / FX
    ws = wb["LIQUIDITY_BUFFER"]; rows = label_rows(ws)
    data["buffer"] = {"modelled_buffer": ws[f"C{find(rows, 'Modelled minimum liquidity buffer', 'LIQUIDITY_BUFFER')}"].value}
    ws = wb["FUNDING"]; rows = label_rows(ws)
    data["funding"] = {
        "weekly_outstanding": [ws[f"{c}{find(rows, 'Funding outstanding (cumulative)', 'FUNDING')}"].value for c in C.WEEK_COLS],
        "weekly_cost": [ws[f"{c}{find(rows, 'Funding cost', 'FUNDING')}"].value for c in C.WEEK_COLS],
        "weekly_util": [ws[f"{c}{find(rows, 'Facility utilisation', 'FUNDING')}"].value for c in C.WEEK_COLS],
        "total_cost": ws[f"B{find(rows, 'Total 13-week funding cost', 'FUNDING')}"].value,
        "peak": ws[f"B{find(rows, 'Peak funding requirement', 'FUNDING')}"].value,
        "rate": ws[f"C{find(rows, 'Modelled funding rate (active scenario)', 'FUNDING')}"].value,
    }
    ws = wb["SURPLUS_CASH"]; rows = label_rows(ws)
    data["surplus_cash"] = {
        "weekly_surplus": [ws[f"{c}{find(rows, 'Surplus cash', 'SURPLUS_CASH')}"].value for c in C.WEEK_COLS],
        "weekly_income": [ws[f"{c}{find(rows, 'Investment income', 'SURPLUS_CASH')}"].value for c in C.WEEK_COLS],
        "total_income": ws[f"B{find(rows, '13-week investment income', 'SURPLUS_CASH')}"].value,
    }
    ws = wb["FX_LIQUIDITY"]; rows = label_rows(ws)
    data["fx"] = {"total_impact": ws[f"G{find(rows, 'Total', 'FX_LIQUIDITY')}"].value}

    # ---- OPTIMISATION: buffer table and the two sensitivity grids
    ws = wb["OPTIMISATION"]; rows = label_rows(ws)
    hdr = find(rows, "Buffer €m", "OPTIMISATION")
    cols = [ws.cell(hdr, c).value for c in range(1, 13)]
    tbl = []
    r = hdr + 1
    while isinstance(ws.cell(r, 1).value, (int, float)):
        tbl.append([ws.cell(r, c).value for c in range(1, 13)]); r += 1
    data["optimisation"] = pd.DataFrame(tbl, columns=cols)
    data["opt_selected"] = ws[f"B{find(rows, 'Model-selected buffer', 'OPTIMISATION')}"].value
    data["opt_drain"] = ws[f"B{find(rows, 'Severe-stress peak drain vs Base', 'OPTIMISATION')}"].value

    def grid(header_label, first_col):
        h = find(rows, header_label, "OPTIMISATION")
        rates = [ws.cell(h, c).value for c in range(first_col, first_col + 6)]
        out = {}
        rr = h + 1
        while isinstance(ws.cell(rr, 1).value, (int, float)):
            out[ws.cell(rr, 1).value] = [ws.cell(rr, c).value for c in range(first_col, first_col + 6)] + [ws.cell(rr, 2).value]
            rr += 1
        return rates, out
    data["sens1_rates"], data["sens1"] = grid("Buffer €m \\ funding rate", 2)
    data["sens2_rates"], data["sens2"] = grid("Delay (days) \\ funding rate", 3)

    # ---- TREASURY_OUTPUT: KPI block (above the comparison) and comparison table (below)
    ws = wb["TREASURY_OUTPUT"]; allrows = label_rows(ws)
    split = next(r for lab, r in allrows.items() if lab.startswith("Scenario comparison"))
    kpi_rows = label_rows(ws, stop=split - 1)
    cmp_rows = label_rows(ws, start=split)
    data["outputs"] = {k: ws[f"B{find(kpi_rows, lab, 'TREASURY_OUTPUT')}"].value for lab, k in C.OUTPUT_KPI_LABELS.items()}
    data["outputs"]["selected"] = ws["B4"].value
    comp = {}
    for lab, k in C.COMPARISON_LABELS.items():
        r = find(cmp_rows, lab, "TREASURY_OUTPUT")
        comp[k] = {s: ws[f"{col}{r}"].value for s, col in zip(C.SCENARIOS, "BCD")}
    data["comparison"] = pd.DataFrame(comp).T

    # ---- STEP3_CHECKS: 12 core check statuses
    ws = wb["STEP3_CHECKS"]
    core = {}
    for r in range(1, ws.max_row + 1):
        n = ws[f"A{r}"].value
        if isinstance(n, (int, str)) and str(n).isdigit() and 1 <= int(n) <= 12:
            core[int(n)] = ws[f"D{r}"].value
    data["excel_checks"] = core
    data["excel_check_summary"] = ws["C4"].value
    return data


if __name__ == "__main__":
    C.OUTPUT.mkdir(exist_ok=True)
    try:
        d = import_excel()
    except Exception as e:
        print(f"IMPORT FAILED: {e}"); sys.exit(1)
    with open(C.IMPORT_PICKLE, "wb") as f:
        pickle.dump(d, f)
    print(f"Imported {C.WORKBOOK.name}: {len(d['sheets_present'])} sheets; missing required: {d['missing_sheets'] or 'none'}")
    print(f"  forecast weeks: {len(d.get('forecast', []))}; scenarios: {d.get('assumption_header')}; selected: {d.get('opening', {}).get('selected')}")