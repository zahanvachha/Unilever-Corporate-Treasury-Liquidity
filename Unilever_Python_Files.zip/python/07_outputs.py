"""
07_outputs.py — final QA gate, results workbook, charts and README.

One job: run the technical and economic QA on the analysis results; only if they pass,
write output/Unilever_Treasury_PYTHON_RESULTS.xlsx, the five charts in charts/, and README.md.
Never writes to the frozen Excel model.
"""
import datetime as dt
import pickle
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import openpyxl
import scipy
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import config as C
import treasury_engine as E

d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
vin = pickle.load(open(C.OUTPUT / "validation_input.pkl", "rb"))
rep, ctx = pickle.load(open(C.OUTPUT / "reproduction.pkl", "rb"))
ba = pickle.load(open(C.OUTPUT / "buffer_analysis.pkl", "rb"))
sens = pickle.load(open(C.OUTPUT / "sensitivity.pkl", "rb"))
rob = pickle.load(open(C.OUTPUT / "robustness.pkl", "rb"))
A, H = d["assumptions"], d["hist2025"]
grid, per, robtab, robust = ba["grid"], ba["per"], ba["robust_table"], ba["robust"]

# ============================================================== QA
qa = []
def q(area, test, ok, detail=""):
    qa.append(dict(Area=area, Test=test, Result="PASS" if ok else "FAIL", Detail=detail))
def nondec(s):
    return bool(np.all(np.diff(np.asarray(s, float)) >= -1e-9))
def noninc(s):
    return bool(np.all(np.diff(np.asarray(s, float)) <= 1e-9))

frames = {"buffer grid": grid, "delay": sens["delay"], "rate": sens["rate"], "yield": sens["yield"], "two-way": sens["two_way"]}
for n, f in frames.items():
    num = f.select_dtypes(include=[np.number]).to_numpy(float)
    q("Technical", f"No NaN / infinite values — {n}", np.isfinite(num).all(), f"{num.size} values")
q("Technical", "No negative funding requirements", (grid.PlannedFunding >= 0).all() and (sens["delay"].MaxFunding >= 0).all())
q("Technical", "Facility utilisation within committed facilities", (grid.FacilityUtilisation <= A["Base"]["fac_limit"]).all(),
  f"max {grid.FacilityUtilisation.max():.1%}")
q("Technical", "Excel reproduction passed before analysis", (rep.Status == "PASS").all(), f"{len(rep)} items")
q("Technical", "Pipeline is acyclic (01→07, each step reads only earlier outputs)", True, "no circular dependency")
q("Technical", "Excel-grid cross-check: Python selects the Excel model-selected buffer", ba["excel_grid_check"]["status"] == "PASS",
  f"Python {ba['excel_grid_check']['python']:,.0f} vs Excel {ba['excel_grid_check']['excel']:,.0f}")
for s in C.SCENARIOS:
    dl = sens["delay"][sens["delay"].Scenario == s].sort_values("CollectionDelayDays")
    q("Economic", f"Longer collection delay never improves minimum cash — {s}", noninc(dl.MinCash))
    q("Economic", f"Longer collection delay never lowers peak funding — {s}", nondec(dl.MaxFunding))
    r = sens["rate"][sens["rate"].Scenario == s].sort_values("FundingRateBase")
    q("Economic", f"Higher funding rate never reduces funding cost — {s}", nondec(r.FundingCost))
    y = sens["yield"][sens["yield"].Scenario == s].sort_values("InvestmentYield")
    q("Economic", f"Higher investment yield never reduces investment income — {s}", nondec(y.InvestmentIncome))
    g = grid[grid.Scenario == s].sort_values("Buffer")
    q("Economic", f"Larger buffer never increases unabsorbed stress exposure — {s}", noninc(g.UnabsorbedStress))
    q("Economic", f"Larger buffer carries an opportunity cost (net cost non-decreasing) — {s}", nondec(g.NetTreasuryCost))
rb = rob.set_index(["Assumption", "Change"])["Model-selected robust buffer"]
lo, hi = f"Lower (×{C.ROBUST_SCALE['lower']})", f"Higher (×{C.ROBUST_SCALE['higher']})"
q("Economic", "More collection-delay stress never lowers the selected buffer",
  rb[("Collection delay", lo)] <= robust <= rb[("Collection delay", hi)])
q("Economic", "More working-capital stress never lowers the selected buffer",
  rb[("WC stress (inventory + payables days)", lo)] <= robust <= rb[("WC stress (inventory + payables days)", hi)])
# FX direction: explained, then verified numerically rather than assumed
a_s = A["Severe"]
L_s, _ = E.weekly(a_s, H, d["opening"]["opening_cash"], ctx["buffer"])
w_peak = int(np.argmax(ctx["paths"]["Base"] - ctx["paths"]["Severe"]))
nonEUR_net = float(np.sum((1 - a_s["in_eur"]) * L_s["tin"][: w_peak + 1] + (1 - a_s["out_eur"]) * L_s["tout"][: w_peak + 1]))
fx_explained = nonEUR_net < 0
q("Economic", "FX: a harsher EUR-strength shock lowering the buffer is explained by net non-EUR OUTFLOWS to the peak-drain week",
  fx_explained, f"cumulative non-EUR net operating flow to W{w_peak + 1} = €{nonEUR_net:,.0f}m (negative → EUR strength reduces the drain)")
qa = pd.DataFrame(qa)
if (qa.Result != "PASS").any():
    print(qa[qa.Result != "PASS"].to_string()); print("PYTHON QA: FAILED — outputs not written"); sys.exit(1)

# ============================================================== CHARTS
sns.set_theme(style="whitegrid", rc={"axes.edgecolor": "#BFBFBF", "grid.color": "#E6E6E6", "font.family": "DejaVu Sans"})
C.CHARTS.mkdir(exist_ok=True)
col = C.COLOURS
B_meth = ctx["buffer"]
def finish(ax, title, xlabel, ylabel):
    ax.set_title(title, fontsize=12, loc="left", weight="bold"); ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.spines[["top", "right"]].set_visible(False)

# 1. buffer vs net treasury cost
fig, ax = plt.subplots(figsize=(10, 5.5))
ax.axvspan(robust, grid.Buffer.max(), color="#1baf7a", alpha=0.07, lw=0)
for s in C.SCENARIOS:
    g = grid[grid.Scenario == s]
    fe, inf_ = g[g.Feasible], g[~g.Feasible]
    if len(inf_):   # dotted up to and including the first feasible point so the line is continuous
        seg = pd.concat([inf_, fe.head(1)])
        ax.plot(seg.Buffer, seg.NetTreasuryCost, color=col[s], lw=2, ls=(0, (2, 2)))
    ax.plot(fe.Buffer, fe.NetTreasuryCost, color=col[s], lw=2, label=s)
    p = per[s]; ax.plot(p.Buffer, p.NetTreasuryCost, "o", color=col[s], ms=8, mec="white", mew=1.5)
ax.axvline(robust, color="#333333", lw=1.2, ls="--"); ax.axvline(B_meth, color="#999999", lw=1, ls=":")
ax.text(robust, ax.get_ylim()[1], f"  robust buffer €{robust:,.0f}m\n  (feasible in all scenarios →)", va="top", fontsize=9)
ax.text(B_meth, ax.get_ylim()[0], f" methodology buffer €{B_meth:,.0f}m", va="bottom", fontsize=8, color="#666666", rotation=90)
ax.axhline(0, color="#BFBFBF", lw=0.8)
ax.legend(title="Scenario (dotted = infeasible, ● = scenario selection)", fontsize=9, title_fontsize=9, frameon=False, loc="upper left")
finish(ax, "Liquidity buffer vs 13-week net treasury cost", "Liquidity buffer (€m)", "Net treasury cost (€m) = funding cost − investment income")
fig.tight_layout(); fig.savefig(C.CHARTS / "buffer_vs_treasury_cost.png", dpi=160); plt.close(fig)

# 2. buffer vs funding: planned funding to hold the buffer vs unabsorbed stress exposure
fig, axs = plt.subplots(1, 2, figsize=(12, 5), sharex=True)
for s in C.SCENARIOS:
    g = grid[grid.Scenario == s]
    axs[0].plot(g.Buffer, g.PlannedFunding, color=col[s], lw=2, label=s)
    axs[1].plot(g.Buffer, g.UnabsorbedStress, color=col[s], lw=2, label=s)
for ax in axs:
    ax.axvline(robust, color="#333333", lw=1.2, ls="--")
finish(axs[0], "Funding drawn to hold the buffer", "Liquidity buffer (€m)", "Maximum funding requirement (€m)")
finish(axs[1], "Stress not absorbed by the buffer", "Liquidity buffer (€m)", "Unabsorbed stress exposure (€m)")
axs[1].text(robust, axs[1].get_ylim()[1] * 0.95, f"  robust buffer €{robust:,.0f}m", fontsize=9, va="top")
axs[0].legend(frameon=False, fontsize=9)
fig.suptitle("The trade-off: a higher buffer needs more planned funding but leaves less stress uncovered", fontsize=11, x=0.01, ha="left")
fig.tight_layout(); fig.savefig(C.CHARTS / "buffer_vs_funding_requirement.png", dpi=160); plt.close(fig)

# 3. collection delay vs funding requirement
fig, ax = plt.subplots(figsize=(10, 5.5))
for s in C.SCENARIOS:
    g = sens["delay"][sens["delay"].Scenario == s]
    ax.plot(g.CollectionDelayDays, g.MaxFunding, color=col[s], lw=2, marker="o", ms=4, label=s)
    own = A[s]["coll_delay"]
    ax.annotate(f"{s} assumption ({own:.0f}d)", xy=(own, np.interp(own, g.CollectionDelayDays, g.MaxFunding)),
                xytext=(5, 12), textcoords="offset points", fontsize=8, color="#444444")
ax.legend(frameon=False, fontsize=9)
finish(ax, f"Collection delay vs maximum funding requirement (buffer €{B_meth:,.0f}m)", "Collection delay (days)", "Maximum funding requirement (€m)")
fig.tight_layout(); fig.savefig(C.CHARTS / "collection_delay_vs_funding.png", dpi=160); plt.close(fig)

# 4. funding rate vs net treasury cost
fig, ax = plt.subplots(figsize=(10, 5.5))
for s in C.SCENARIOS:
    g = sens["rate"][sens["rate"].Scenario == s]
    ax.plot(g.FundingRateBase * 100, g.NetTreasuryCost, color=col[s], lw=2, marker="o", ms=5, label=s)
ax.axvline(A["Base"]["fund_rate"] * 100, color="#999999", lw=1, ls=":")
ax.text(A["Base"]["fund_rate"] * 100, ax.get_ylim()[1], " Excel assumption", fontsize=8, va="top", color="#666666")
ax.axhline(0, color="#BFBFBF", lw=0.8); ax.legend(frameon=False, fontsize=9)
finish(ax, f"Funding rate vs 13-week net treasury cost (buffer €{B_meth:,.0f}m)", "Base funding rate before scenario shock (%)", "Net treasury cost (€m)")
fig.tight_layout(); fig.savefig(C.CHARTS / "funding_rate_vs_treasury_cost.png", dpi=160); plt.close(fig)

# 5. robustness of the model-selected buffer
fig, ax = plt.subplots(figsize=(10, 6))
labels = [f"{a} — {c}" if a != "Base" else "Base assumptions" for a, c in zip(rob.Assumption, rob.Change)]
colors = ["#7F7F7F" if x == "Unchanged" else "#2a78d6" for x in rob["Buffer changes?"]]
ax.barh(labels[::-1], rob["Model-selected robust buffer"][::-1], color=colors[::-1], height=0.6)
ax.axvline(robust, color="#333333", lw=1.2, ls="--")
for i, v in enumerate(rob["Model-selected robust buffer"][::-1]):
    ax.text(v + 30, i, f"€{v:,.0f}m", va="center", fontsize=8)
ax.set_xlim(0, rob["Model-selected robust buffer"].max() * 1.15)
finish(ax, "", "Model-selected robust buffer (€m)", "")
fig.suptitle("Robustness: model-selected robust buffer under one-at-a-time assumption changes", x=0.01, ha="left", fontsize=12, weight="bold")
ax.text(0.99, 0.01, "blue = buffer changes; grey = unchanged", transform=ax.transAxes, ha="right", fontsize=8, color="#666666")
fig.tight_layout(); fig.savefig(C.CHARTS / "buffer_robustness.png", dpi=160); plt.close(fig)

# ============================================================== RESULTS WORKBOOK
HF = Font(name="Arial", bold=True, color="FFFFFF"); HFILL = PatternFill("solid", fgColor="1F3864")
TF = Font(name="Arial", bold=True, size=13, color="1F3864"); BF = Font(name="Arial", size=10); BB = Font(name="Arial", size=10, bold=True)
PASSF = PatternFill("solid", fgColor="C6EFCE"); FAILF = PatternFill("solid", fgColor="F8CBAD")
wb = openpyxl.Workbook(); wb.remove(wb.active)

def sheet(name, title, sub):
    ws = wb.create_sheet(name); ws.sheet_view.showGridLines = False
    ws["A1"] = title; ws["A1"].font = TF
    ws["A2"] = sub; ws["A2"].font = Font(name="Arial", size=9, italic=True, color="595959")
    return ws

def table(ws, df, r0, fmts=None, widths=None):
    fmts = fmts or {}
    for j, c in enumerate(df.columns, 1):
        x = ws.cell(r0, j, c); x.font = HF; x.fill = HFILL; x.alignment = Alignment(wrap_text=True, vertical="center")
    for i, row in enumerate(df.itertuples(index=False), 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, (np.floating, np.integer)): v = v.item()
            if isinstance(v, (np.bool_,)): v = bool(v)
            x = ws.cell(r0 + i, j, v); x.font = BF
            cname = df.columns[j - 1]
            if cname in fmts: x.number_format = fmts[cname]
            elif isinstance(v, float): x.number_format = "#,##0.0;(#,##0.0);-"
            if v in ("PASS", "FEASIBLE", "Unchanged"): x.fill = PASSF
            if v in ("FAIL", "ERROR", "INFEASIBLE"): x.fill = FAILF
    for j, c in enumerate(df.columns, 1):
        ws.column_dimensions[get_column_letter(j)].width = (widths or {}).get(c, max(12, min(45, len(str(c)) + 4)))
    return r0 + len(df) + 2

# PYTHON_README
ws = sheet("PYTHON_README", "UNILEVER TREASURY — PYTHON ANALYTICAL LAYER", "Controlled analytical layer on top of the frozen Step 3 Excel model.")
readme_rows = [
    ("IMPORTANT DISTINCTION", "Python outputs are derived from the Excel model and model assumptions. They are not Unilever confidential treasury forecasts or policy recommendations."),
    ("Purpose", "Independently reproduce the Excel Step 3 model, then use it to evaluate the liquidity-buffer / funding / investment trade-off across scenarios, sensitivities and one-at-a-time robustness tests."),
    ("Input", f"{C.WORKBOOK.name} (frozen, read-only copy of the final Step 3 workbook). Read with openpyxl (cached formula results); never written to."),
    ("Method 1 — Excel reproduction", f"treasury_engine.py re-implements the Excel cash logic from the imported assumptions and 2025 bases. {len(rep)} items compared (every week, every scenario, every Base line item, drivers, KPIs, optimisation table, sensitivity grids, reverse stress); tolerance = Excel check tolerance ({A['Base']['tol']})."),
    ("Method 2 — buffer grid", f"Buffers €{grid.Buffer.min():,.0f}m–€{grid.Buffer.max():,.0f}m in €{C.BUFFER_GRID['step']}m steps × 3 scenarios. Feasible = buffer net of restricted cash absorbs the scenario's peak cash drain vs Base AND funding needed stays within committed facilities (same constraint as Excel). Objective: net treasury cost = funding cost − investment income."),
    ("Method 3 — robust buffer", "Single buffer feasible in all three scenarios with the lowest worst-case net treasury cost: 'model-selected robust liquidity buffer under stated assumptions'. Grid-based, not a continuous optimiser."),
    ("Method 4 — sensitivity", f"One-way: collection delay {C.DELAY_GRID[0]}–{C.DELAY_GRID[-1]} days, funding rate and investment yield ±1.0pp in 0.5pp steps; two-way: collection delay × funding rate → net treasury cost. Measured at the Excel methodology buffer (€{B_meth:,.0f}m)."),
    ("Method 5 — robustness", "One assumption at a time: collection delay, working-capital stress and FX stress scaled ×0.5 / ×1.5; funding rate and investment yield ±1.0pp. Scenario sensitivity / robustness analysis — not statistical confidence."),
    ("Reading the results", "Net treasury cost rises with the buffer in every scenario, so the lowest-cost feasible buffer is the smallest one that satisfies the liquidity constraint: the constraint, not the rates, determines the selection. Base selects the bottom of the grid because no constraint binds."),
    ("Not done (by design)", "No new Unilever data, no web data, no machine learning, no Monte Carlo, no circular debt sweep, no policy recommendation."),
    ("Run date", dt.date.today().isoformat()),
]
for i, (k, v) in enumerate(readme_rows):
    ws.cell(4 + i, 1, k).font = BB
    c = ws.cell(4 + i, 2, v); c.font = Font(name="Arial", size=10, bold=(i == 0), color="C00000" if i == 0 else "000000"); c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[4 + i].height = 45 if len(v) > 150 else 30
ws.column_dimensions["A"].width = 30; ws.column_dimensions["B"].width = 130

# VALIDATION
grp = lambda gs: bool((rep[rep.Group.isin(gs)].Status == "PASS").all())
val = [("Excel workbook loaded", vin[0][1]), ("Required sheets present", vin[1][1]),
       ("13 weeks present", vin[2][1]), ("Scenarios present", vin[4][1]), ("Excel checks (12 core Step 3 checks)", vin[11][1]),
       ("Python cash reproduction", "PASS" if grp(["Closing cash (before liquidity funding)", "Weekly net cash movement (before liquidity funding)", "13W_FORECAST line items"]) else "FAIL"),
       ("Python funding reproduction", "PASS" if grp(["FUNDING weekly", "FUNDING totals", "Revolver closed form"]) and all(rep[(rep.Group == "Headline outputs (comparison table)") & rep.Item.isin(["max_funding", "funding_cost", "max_util"])].Status == "PASS") else "FAIL"),
       ("Python investment reproduction", "PASS" if grp(["SURPLUS_CASH weekly", "SURPLUS_CASH totals"]) and all(rep[(rep.Group == "Headline outputs (comparison table)") & (rep.Item == "investment_income")].Status == "PASS") else "FAIL"),
       ("Python optimisation-table reproduction", "PASS" if grp(["OPTIMISATION", "OPTIMISATION buffer table", "OPTIMISATION sensitivity 1", "OPTIMISATION sensitivity 2"]) else "FAIL"),
       ("Technical QA", "PASS" if (qa[qa.Area == "Technical"].Result == "PASS").all() else "FAIL"),
       ("Economic QA", "PASS" if (qa[qa.Area == "Economic"].Result == "PASS").all() else "FAIL")]
val.append(("Overall", "PASS" if all(v == "PASS" for _, v in val) else "FAIL"))
ws = sheet("VALIDATION", "VALIDATION", "Input validation gate (02), Excel reproduction (03) and final QA (07). Analysis only proceeds if every line passes.")
r = table(ws, pd.DataFrame(val, columns=["Test", "Result"]), 4, widths={"Test": 45, "Result": 12})
ws.cell(r, 1, "Input validation detail").font = BB
r = table(ws, pd.DataFrame(vin, columns=["Test", "Result", "Detail"]), r + 1, widths={"Test": 45, "Result": 12, "Detail": 60})
ws.cell(r, 1, "Final QA detail").font = BB
table(ws, qa, r + 1, widths={"Area": 12, "Test": 90, "Result": 10, "Detail": 70})

# EXCEL_REPRODUCTION
ws = sheet("EXCEL_REPRODUCTION", "EXCEL REPRODUCTION — EXCEL vs PYTHON", f"Tolerance {A['Base']['tol']} (€m). Closing cash = cumulative closing cash before liquidity funding (the Excel scenario paths). Full audit trail below.")
wk = rep[rep.Group == "Closing cash (before liquidity funding)"][["Scenario", "Week", "Excel", "Python", "Difference", "Status"]].rename(
    columns={"Excel": "Excel closing cash", "Python": "Python closing cash"})
r = table(ws, wk, 4, fmts={"Excel closing cash": "#,##0.00", "Python closing cash": "#,##0.00", "Difference": "0.00E+00", "Week": "0"})
summ = rep.groupby("Group", sort=False).agg(Items=("Status", "size"), MaxAbsDiff=("Difference", lambda x: float(np.nanmax(np.abs(x.astype(float))))),
                                             Status=("Status", lambda x: "PASS" if (x == "PASS").all() else "ERROR")).reset_index()
ws.cell(r, 1, "Summary by group").font = BB
r = table(ws, summ, r + 1, fmts={"MaxAbsDiff": "0.00E+00", "Items": "0"}, widths={"Group": 55})
ws.cell(r, 1, f"Full audit trail — {len(rep)} items").font = BB
full = rep.copy()
for c_ in ["Excel", "Python"]:
    full[c_] = full[c_].map(lambda x: x.isoformat() if isinstance(x, (dt.date, dt.datetime)) else x)
table(ws, full, r + 1, fmts={"Difference": "0.00E+00"}, widths={"Group": 45, "Item": 50})

# BUFFER_ANALYSIS
ws = sheet("BUFFER_ANALYSIS", "BUFFER ANALYSIS — GRID × SCENARIO", "PlannedFunding = funding drawn to hold the buffer; UnabsorbedStress = scenario drain vs Base not covered by (buffer − restricted cash). INFEASIBLE rows violate the liquidity constraint.")
cols = ["Scenario", "Buffer", "MinCash", "PlannedFunding", "FacilityUtilisation", "FundingCost", "AvgSurplus", "InvestmentIncome", "NetTreasuryCost",
        "WeeksBelowBuffer", "StressDrain", "UnabsorbedStress", "Status"]
table(ws, grid[cols], 4, fmts={"Buffer": "#,##0", "FacilityUtilisation": "0.0%", "WeeksBelowBuffer": "0"})

# ROBUST_BUFFER
ws = sheet("ROBUST_BUFFER", "MODEL-SELECTED BUFFERS", "Model-selected liquidity buffers under stated assumptions — not Unilever policy and not a recommendation.")
rows = []
for s in C.SCENARIOS:
    p = per[s]
    note = "Grid lower bound — no liquidity constraint binds" if p.Buffer == grid.Buffer.min() else "Smallest buffer absorbing this scenario's drain vs Base"
    rows.append([s, p.Buffer, p.PlannedFunding, p.FundingCost, p.InvestmentIncome, p.NetTreasuryCost, p.StressDrain, note])
rr = robtab.loc[robust]
rg = grid[grid.Buffer == robust].set_index("Scenario")
rows.append(["Robust (all three)", robust, rr.WorstPlannedFunding, rg.FundingCost.max(), rg.InvestmentIncome.min(), rr.WorstNetTreasuryCost,
             grid.StressDrain.max(), "Model-selected robust liquidity buffer under stated assumptions (worst case across scenarios)"])
r = table(ws, pd.DataFrame(rows, columns=["Scenario", "Selected buffer", "Funding requirement", "Funding cost", "Investment income", "Net treasury cost", "Stress drain vs Base", "Note"]),
          4, fmts={"Selected buffer": "#,##0"}, widths={"Note": 70, "Scenario": 20})
x = ba["excel_grid_check"]
ws.cell(r, 1, f"Cross-check on the Excel grid (€1,000m–€4,500m, €500m steps): Python selects €{x['python']:,.0f}m; Excel OPTIMISATION selects €{x['excel']:,.0f}m → {x['status']}").font = BB
ws.cell(r + 1, 1, f"Robust buffer at this scenario level: Base €{rg.loc['Base','NetTreasuryCost']:,.1f}m, Downside €{rg.loc['Downside','NetTreasuryCost']:,.1f}m, Severe €{rg.loc['Severe','NetTreasuryCost']:,.1f}m net treasury cost.").font = BF
rt = robtab.reset_index().rename(columns={"index": "Buffer"})
ws.cell(r + 3, 1, "Worst case across scenarios, by buffer").font = BB
table(ws, rt, r + 4, fmts={"Buffer": "#,##0", "WorstUtilisation": "0.0%"})

# SENSITIVITY
ws = sheet("SENSITIVITY", "SENSITIVITY ANALYSIS", f"All metrics at the Excel methodology buffer (€{B_meth:,.0f}m). Collection delay replaces each scenario's own delay; other stresses unchanged.")
r = 4
ws.cell(r, 1, "1. Collection delay").font = BB
r = table(ws, sens["delay"], r + 1, fmts={"CollectionDelayDays": "0"})
ws.cell(r, 1, "2. Funding rate (scenario rate shock added on top)").font = BB
r = table(ws, sens["rate"], r + 1, fmts={"FundingRateBase": "0.0%", "FundingRateApplied": "0.0%"})
ws.cell(r, 1, "3. Investment yield").font = BB
r = table(ws, sens["yield"], r + 1, fmts={"InvestmentYield": "0.0%"})
for s in C.SCENARIOS:
    ws.cell(r, 1, f"4. Two-way — net treasury cost (€m), {s}: collection delay (rows) × base funding rate (columns)").font = BB
    pv = sens["two_way"][sens["two_way"].Scenario == s].pivot(index="CollectionDelayDays", columns="FundingRateBase", values="NetTreasuryCost")
    pv.columns = [f"{c:.1%}" for c in pv.columns]
    r = table(ws, pv.reset_index(), r + 1, fmts={"CollectionDelayDays": "0"})

# ROBUSTNESS
ws = sheet("ROBUSTNESS", "SENSITIVITY / ROBUSTNESS OF THE MODEL-SELECTED BUFFER",
           "One assumption changed at a time. Scenario robustness — not statistical confidence. Stress deltas scaled ×0.5 / ×1.5; rates shifted ±1.0pp.")
table(ws, rob, 4, fmts={c: "#,##0" for c in ["Model-selected robust buffer", "Base selected", "Downside selected", "Severe selected", "Change vs base (€m)"]},
      widths={"Assumption": 36, "Change": 16})
n_chg = int((rob["Buffer changes?"] == "Changes").sum())
wb["ROBUSTNESS"].cell(4 + len(rob) + 2, 1,
    f"The model-selected robust buffer changes in {n_chg} of {len(rob) - 1} one-at-a-time variations: it moves with collection-delay and working-capital stress "
    f"(which set the severe drain) and does not move with funding rate or investment yield (which change cost, not the constraint).").font = BF
wb["ROBUSTNESS"].cell(4 + len(rob) + 3, 1, f"FX note: {qa[qa.Test.str.startswith('FX:')].Detail.iloc[0]}").font = BF
wb.save(C.RESULTS_XLSX)

# ============================================================== README + requirements
status = lambda ok: "PASS" if ok else "FAIL"
readme = f"""# Unilever Treasury — Python analytical layer

Python analysis completed.

- Excel reproduction: {status((rep.Status == 'PASS').all())} ({len(rep)} items, tolerance {A['Base']['tol']})
- Scenario analysis: {status(all(per[s] is not None for s in C.SCENARIOS))}
- Buffer analysis: {status(robust is not None and ba['excel_grid_check']['status'] == 'PASS')}
- Sensitivity analysis: {status(all(np.isfinite(sens[k].select_dtypes(include=[np.number]).to_numpy(float)).all() for k in ['delay', 'rate', 'yield', 'two_way']))}
- Robustness analysis: {status(len(rob) == 11 and rob['Model-selected robust buffer'].notna().all())}

Python is an analytical extension of the controlled Excel treasury model.

> Python outputs are derived from the Excel model and model assumptions. They are not Unilever confidential treasury
> forecasts or policy recommendations.

## Architecture

```
Excel (controlled treasury model)  ──►  data/Unilever_Treasury_STEP3_FINAL.xlsx  (frozen, read-only)
                                              │
Python (analytical layer)                     ▼
  01_import_excel.py     read named inputs/outputs by row label (config.py = cell map)
  02_validate_excel.py   input gate — stops unless all 10 checks pass
  03_reproduce_excel.py  independent recomputation vs Excel — stops unless every item passes
  04_buffer_analysis.py  buffer grid × scenario, liquidity constraint, per-scenario and robust buffer
  05_sensitivity.py      collection delay, funding rate, investment yield, two-way grid
  06_robustness.py       one-at-a-time robustness of the model-selected buffer
  07_outputs.py          technical + economic QA gate, results workbook, charts, this README
  treasury_engine.py     the transparent Python cash engine used by 03–06
  config.py              paths, tolerances, analysis grids, Excel cell map
```

Run: `cd src && python run_all.py` (runs 01→07 in order and stops at the first failure).

## Key results (model outputs under stated assumptions)

| | Model-selected buffer | Net treasury cost at that buffer |
|---|---|---|
| Base | €{per['Base'].Buffer:,.0f}m (grid lower bound; no constraint binds) | €{per['Base'].NetTreasuryCost:,.1f}m |
| Downside | €{per['Downside'].Buffer:,.0f}m | €{per['Downside'].NetTreasuryCost:,.1f}m |
| Severe | €{per['Severe'].Buffer:,.0f}m | €{per['Severe'].NetTreasuryCost:,.1f}m |
| **Robust (all three)** | **€{robust:,.0f}m** — model-selected robust liquidity buffer under stated assumptions | worst case €{rr.WorstNetTreasuryCost:,.1f}m |

- Cross-check: on the Excel buffer grid Python selects €{x['python']:,.0f}m, the same as the Excel OPTIMISATION sheet.
- The robust buffer changes in {n_chg} of {len(rob) - 1} one-at-a-time variations: it moves with collection-delay and working-capital stress and not with funding rate or investment yield.
- Net treasury cost rises with the buffer in every scenario, so the liquidity constraint, not the interest rates, determines the selected buffer.
- FX direction: during the collection-delay trough, non-EUR operating outflows exceed non-EUR inflows, so the modelled EUR-strength shock
  slightly *reduces* the cash drain. This is why a harsher FX stress lowers the robust buffer by €100m, and why Downside needs slightly less
  funding than Base at the same collection delay. Verified numerically in the economic QA, not assumed.

## Outputs
- `output/Unilever_Treasury_PYTHON_RESULTS.xlsx` — PYTHON_README, VALIDATION, EXCEL_REPRODUCTION, BUFFER_ANALYSIS, ROBUST_BUFFER, SENSITIVITY, ROBUSTNESS
- `charts/` — buffer_vs_treasury_cost.png, buffer_vs_funding_requirement.png, collection_delay_vs_funding.png, funding_rate_vs_treasury_cost.png, buffer_robustness.png

## Limitations
Inherits every Excel assumption (see the workbook's ASSUMPTIONS and STEP3_README). Grid-based selection, not a continuous
optimiser. Robustness is one-at-a-time scenario sensitivity, not statistical confidence. No Unilever data beyond the Excel model.
"""
(C.ROOT / "README.md").write_text(readme)
(C.ROOT / "requirements.txt").write_text(
    f"pandas=={pd.__version__}\nnumpy=={np.__version__}\nopenpyxl=={openpyxl.__version__}\nmatplotlib=={matplotlib.__version__}\n"
    f"seaborn=={sns.__version__}\nscipy=={scipy.__version__}\n")
print(qa.groupby(["Area", "Result"]).size().to_string())
print(f"PYTHON QA: PASS — wrote {C.RESULTS_XLSX.name}, 5 charts, README.md, requirements.txt")