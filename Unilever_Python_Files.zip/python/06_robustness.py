"""
06_robustness.py — sensitivity / robustness of the model-selected buffer (one assumption at a time).

One job: change one assumption, rerun the reproduced engine and the buffer selection, and record
whether the model-selected robust buffer moves. This is scenario sensitivity, NOT statistical robustness.
Output: output/robustness.pkl
"""
import importlib
import pickle
import numpy as np
import pandas as pd
import config as C
import treasury_engine as E

ba = importlib.import_module("04_buffer_analysis")


def variants(A):
    lo, hi, sh = C.ROBUST_SCALE["lower"], C.ROBUST_SCALE["higher"], C.RATE_SHIFT
    def scale(keys, k):
        return lambda a: {**a, **{x: a[x] * k for x in keys}}
    def shift(key, dx):
        return lambda a: {**a, key: a[key] + dx}
    return [
        ("Base", "Base", lambda a: dict(a)),
        ("Collection delay", f"Lower (×{lo})", scale(["coll_delay"], lo)),
        ("Collection delay", f"Higher (×{hi})", scale(["coll_delay"], hi)),
        ("Funding rate", f"Lower ({-sh:+.1%})", shift("fund_rate", -sh)),
        ("Funding rate", f"Higher ({sh:+.1%})", shift("fund_rate", sh)),
        ("Investment yield", f"Lower ({-sh:+.1%})", shift("yield", -sh)),
        ("Investment yield", f"Higher ({sh:+.1%})", shift("yield", sh)),
        ("WC stress (inventory + payables days)", f"Lower (×{lo})", scale(["inv_days", "pay_days"], lo)),
        ("WC stress (inventory + payables days)", f"Higher (×{hi})", scale(["inv_days", "pay_days"], hi)),
        ("FX stress", f"Lower (×{lo})", scale(["fx_shock"], lo)),
        ("FX stress", f"Higher (×{hi})", scale(["fx_shock"], hi)),
    ]


def run(d, ctx):
    A, H, opening = d["assumptions"], d["hist2025"], d["opening"]["opening_cash"]
    g = C.BUFFER_GRID
    grid = np.arange(g["start"], g["stop"] + g["step"], g["step"], dtype=float)
    rows = []
    for assumption, change, fn in variants(A):
        A2 = {s: fn(A[s]) for s in C.SCENARIOS}
        buffer = E.methodology_buffer(A2["Base"], H)
        paths = {s: E.cash_path(A2[s], H, opening, buffer)[0] for s in C.SCENARIOS}
        df = ba.evaluate(A2, H, opening, grid, paths, ctx["facility"])
        per, rob, robust = ba.select(df)
        r = rob.loc[robust] if robust is not None else None
        rows.append({"Assumption": assumption, "Change": change,
                     "Model-selected robust buffer": robust,
                     "Base selected": per["Base"].Buffer if per["Base"] is not None else None,
                     "Downside selected": per["Downside"].Buffer if per["Downside"] is not None else None,
                     "Severe selected": per["Severe"].Buffer if per["Severe"] is not None else None,
                     "Severe stress drain": float(np.max(paths["Base"] - paths["Severe"])),
                     "Worst-case planned funding": r.WorstPlannedFunding if r is not None else None,
                     "Worst-case net treasury cost": r.WorstNetTreasuryCost if r is not None else None})
    df = pd.DataFrame(rows)
    base = df.loc[0, "Model-selected robust buffer"]
    df["Change vs base (€m)"] = df["Model-selected robust buffer"] - base
    df["Buffer changes?"] = np.where(df["Change vs base (€m)"] == 0, "Unchanged", "Changes")
    return df


if __name__ == "__main__":
    d = pickle.load(open(C.IMPORT_PICKLE, "rb"))
    rep, ctx = pickle.load(open(C.OUTPUT / "reproduction.pkl", "rb"))
    df = run(d, ctx)
    pickle.dump(df, open(C.OUTPUT / "robustness.pkl", "wb"))
    print(df[["Assumption", "Change", "Model-selected robust buffer", "Change vs base (€m)", "Buffer changes?", "Worst-case net treasury cost"]].to_string(index=False))
    n = (df["Buffer changes?"] == "Changes").sum()
    print(f"\nThe model-selected robust buffer changes in {n} of {len(df) - 1} one-at-a-time variations.")