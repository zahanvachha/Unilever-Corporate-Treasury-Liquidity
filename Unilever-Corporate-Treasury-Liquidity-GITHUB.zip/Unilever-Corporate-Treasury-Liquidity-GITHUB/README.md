# Corporate Treasury & Liquidity Management at Unilever plc

A public-data study of short-term liquidity, funding and cash investment at a multinational consumer-goods company, built using **Excel and Python**.

> **Key result:** The model-selected robust liquidity buffer is **€3.5bn** under the stated assumptions. This is a model output, not Unilever's actual liquidity policy or a recommendation to the company.

## Project overview

The project asks:

> **How should a multinational manage short-term liquidity while balancing liquidity protection against the cost of holding cash?**

The analysis was designed around a practical corporate-treasury problem: annual cash generation can be strong while short-term liquidity can still become constrained if customer receipts are delayed, working capital deteriorates or funding conditions tighten.

The project has three layers:

1. **Historical financial model** — reconstructs profitability, cash generation, debt and working capital from 2021–2025 public disclosures.
2. **Excel treasury model** — produces a 13-week cash forecast under Base, Downside and Severe scenarios, including liquidity buffers, funding, surplus cash and FX analysis.
3. **Python analytical layer** — independently reproduces the Excel model and performs buffer optimisation, sensitivity and robustness analysis.

## Key findings

| Scenario | Model-selected buffer |
|---|---:|
| Base | €1.0bn |
| Downside | €1.2bn |
| Severe | €3.5bn |
| **Robust — all three scenarios** | **€3.5bn** |

The main findings are:

- **Collection timing is the dominant liquidity driver.** Delayed customer receipts create a substantially larger change in the required buffer than changes in funding rates or investment yields.
- **The €3.5bn robust buffer is constraint-driven rather than rate-driven.** It is the first level on the tested €100m grid that covers the Severe cash drain while remaining within the committed facilities.
- **Rates affect the cost of liquidity, not its required size** in the tested range. A ±1 percentage-point change in funding rate or investment yield did not change the selected robust buffer.
- **Python independently validates the Excel model.** All 842 comparisons agreed within a €0.01m tolerance, with the largest difference of approximately 10⁻¹¹.
- **The project highlights the importance of cash-flow visibility.** Accurate receivables, payables and payment-timing data are central to determining how much liquidity a corporate needs.

## What was built

### Historical analysis

The historical model covers:

- Income statement
- Balance sheet
- Cash flow
- Financial liabilities
- Net debt
- Free cash flow
- Working capital
- Historical reconciliation checks

The model controls the 2023 reporting-basis change following the Ice Cream demerger by keeping original and continuing-operation figures separate.

### 13-week treasury model

The Excel model includes:

- Weekly cash forecasting
- Base / Downside / Severe scenarios
- Liquidity-buffer methodology
- Committed-facility funding
- Surplus-cash investment
- FX liquidity analysis
- Grid-based buffer optimisation
- Automated model checks

The model uses public disclosures and clearly separates reported figures, derived calculations and modelling assumptions.

### Python analysis

Python is used as an independent analytical layer rather than as a second competing model.

The pipeline:

1. Imports and validates the Excel inputs
2. Reproduces the Excel model independently
3. Tests liquidity-buffer levels
4. Runs sensitivity analysis
5. Runs robustness tests
6. Produces analytical outputs and charts

## Visual results

### 13-week liquidity profile

![13-week liquidity profile](./charts/liquidity_profile.png)

### Liquidity buffer vs. treasury cost

![Liquidity buffer vs. treasury cost](./charts/buffer_vs_cost.png)

### Buffer sensitivity

![Liquidity buffer sensitivity](./charts/buffer_sensitivity.png)

## Technology

- **Microsoft Excel** — historical financial model and treasury forecast
- **Python** — independent validation and analysis
- **pandas / NumPy** — data handling and numerical analysis
- **SciPy** — optimisation and robustness analysis
- **Matplotlib** — charts

## Repository structure

```text
unilever-corporate-treasury-liquidity/
│
├── README.md
├── report/
│   └── Unilever_Corporate_Treasury_Liquidity_Project.pdf
├── excel/
│   └── Unilever_Treasury_Liquidity_Model.xlsx
├── python/
│   ├── run_all.py
│   ├── treasury_engine.py
│   ├── config.py
│   ├── 01_import_excel.py
│   ├── 02_validate_excel.py
│   ├── 03_reproduce_excel.py
│   ├── 04_buffer_analysis.py
│   ├── 05_sensitivity.py
│   ├── 06_robustness.py
│   └── 07_outputs.py
├── results/
│   └── Unilever_Treasury_Python_Results.xlsx
├── charts/
├── requirements.txt
├── LICENSE
└── .gitignore
```

## Important limitations

This is a **public-data research project**, not a reconstruction of Unilever's internal treasury system.

The main limitations are:

- Weekly cash flows are modelled using assumed timing because daily or weekly operating cash data are not publicly available.
- FX is modelled as a simplified operating-flow shock and does not model jurisdiction-level cash trapping, capital controls or detailed cash-pooling constraints.
- Commercial Paper is excluded because public disclosures do not provide sufficient information to model its availability, pricing and investor appetite under stress.
- The model uses committed bank facilities as the explicit liquidity backstop.
- The liquidity-buffer methodology is constructed for the project and is **not Unilever's disclosed treasury policy**.
- The €2.0% investment yield and 4.3% funding-cost proxy are modelling inputs based on disclosed/reference rates, not Unilever's actual negotiated terms.
- The optimisation searches a fixed €100m grid rather than solving a continuous optimisation problem.

With proprietary treasury data, a future iteration could incorporate jurisdiction-level cash-pooling constraints, a multi-layer funding hierarchy and daily rather than weekly cash forecasting. These are also areas where transaction banks provide infrastructure and services to corporate treasurers.

## Data sources

The historical analysis uses public disclosures including:

- Unilever Annual Reports 2022–2025
- Unilever full-year results announcements
- Machine-readable financial statements filed with the U.S. Securities and Exchange Commission
- Unilever's restated continuing-operations information following the Ice Cream demerger

All material modelling assumptions are identified separately from reported data.

## Full report

For the full methodology, assumptions, results, charts and limitations:

**[Read the full project report](./report/Unilever_Corporate_Treasury_Liquidity_Project.pdf)**

---

### Disclaimer

This project is an independent student analysis based on public information. It does not represent Unilever's internal forecasts, treasury policy, funding arrangements or investment decisions. The €3.5bn liquidity-buffer figure is a model-selected result under the stated assumptions and should not be interpreted as a recommendation to Unilever.
